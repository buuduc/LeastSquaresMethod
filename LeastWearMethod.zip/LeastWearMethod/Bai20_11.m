clc
close all
fprintf('bai 20.11')
X=[0 1 2 3 4 5 6]
Y=[0.1 0.332 1.102 1.664 2.453 3.660 5.460]
bac1(X,Y)
bac2(X,Y)