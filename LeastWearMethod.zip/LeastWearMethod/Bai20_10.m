clc
close all
fprintf('bai 20.10')
X=[135 105 100]
Y=[2 3 5]
bac1(X,Y)
bac2(X,Y)