# LeastWearMethod
 Matlab 
