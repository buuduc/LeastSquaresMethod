clc
close all
fprintf('Bai 20.13')
%% Nhap input dau vao
H=[182 180 179 187 189 194 195 193 200]
W=[74 88 94 78 84 98 76 86 96]
A=[1.92 2.11 2.15 2.02 2.09 2.31 2.02 2.16 2.31]
%% xap xi ham the hien moi lien he chieu cao va dien tich da 
bac1(H,A)
bac2(H,A)
%% xap xi ham the hien moi lien he can nang va dien tich da
bac1(W,A)
bac2(W,A)